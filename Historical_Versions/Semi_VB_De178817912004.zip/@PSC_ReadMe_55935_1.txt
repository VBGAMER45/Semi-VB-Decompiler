Title: Semi VB Decompiler 0.03
Description: Release 0.03
Added Ocx Support
Added P-Code procedure decompile to P-Code tokens.
Added Image Extraction
Added Better Handling of Control properties.
Added Form Patch Editor
Added Syntax Coloring.
Better support of User Controls/And MDI Forms.
Api's Recovered
Procedure Names recovered for Forms and classes.
Resizing of the windows added.
Numerous Bug fixes and other things added.
Begun work on a basic antidecompiler.
Features Advanced decompiling using COM via VB6.OLB
Using COM allows me not to have to hard code every single property
The only properties that need to be hardcoded is the size, font, and dataformat opcodes.
One day I hope to use msvbvm60.dll instead of vb6.olb so nothing will have to be hardcoded.
This is the best Open Source VB Decompiler you can find.
Show your support and leave comments and vote.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55935&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
