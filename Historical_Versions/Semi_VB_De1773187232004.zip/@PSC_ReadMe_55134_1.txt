Title: Semi VB Decompiler
Description: A Semi VB Decomiler. Decompiles the interface using COM. COM is not always correct in the datatypes it returns for a certain property. I started this project a week ago after seeing there were no good open source vb interface decompilers and the other examples on this site are not very good. Another reason is there are some companies that charge for just decompiling the interface which I do not think is very fair. This is not complete but use it as a guide to making your own interface decompiler and maybe make something more. Hope you can learn something from this.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55134&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
